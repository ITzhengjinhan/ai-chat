<template>
  <view>
    <!-- use-chat-record-mode：开启聊天记录模式 -->
    <!-- use-virtual-list：开启虚拟列表模式 -->
    <!-- cell-height-mode：设置虚拟列表模式高度不固定 -->
    <!-- safe-area-inset-bottom：开启底部安全区域适配 -->
    <!-- bottom-bg-color：设置slot="bottom"容器的背景色，这里设置为和chat-input-bar的背景色一致 -->
    <z-paging
      ref="paging"
      v-model="talkList"
      use-chat-record-mode
      use-virtual-list
      cell-height-mode="dynamic"
      safe-area-inset-bottom
      bottom-bg-color="#f8f8f8"
      @query="getHistoryMsg"
      @keyboardHeightChange="keyboardHeightChange"
      @hidedKeyboard="hidedKeyboard"
    >
      <!-- style="transform: scaleY(-1)"必须写，否则会导致列表倒置！！！ -->
      <!-- 注意不要直接在chat-item组件标签上设置style，因为在微信小程序中是无效的，请包一层view -->
      <template #cell="{ item }">
        <view style="transform: scaleY(-1)">
          <chat-item :item="item"></chat-item>
        </view>
      </template>

      <!-- style="transform: scaleY(-1)"必须写，否则会导致列表倒置！！！ -->
      <template #header>
        <view
          style="transform: scaleY(-1); display: flex; justify-content: center"
        >
          <view
            @click="stopChat"
            v-if="isTyping"
            :style="{
              backgroundColor: '#007aff',
              padding: '12rpx 32rpx',
              margin: '20rpx 0',
              borderRadius: '50rpx',
              display: 'inline-flex',
              alignItems: 'center',
              justifyContent: 'center',
              position: 'relative',
            }"
            class="custom-stop-btn"
          >
            <text style="color: #fff">停止会话</text>
          </view>
        </view>
      </template>

      <!-- 底部聊天输入框 -->
      <template #bottom>
        <chat-input-bar ref="inputBar" @send="send" @handleOpen="handleopen" />
      </template>
    </z-paging>

    <user-setting-model
      ref="settingPopup"
      @settings-change="updateUserSetting"
      @resetList="resetList"
    ></user-setting-model>
    <u-top-tips ref="uTips"></u-top-tips>
  </view>
</template>

<script>
const globalData = getApp().globalData;
import { MODEL_TYPE } from "../../constant/model.js";
import chatInputBar from "@/components/chat-input-bar/chat-input-bar.vue";
import chatItem from "@/components/chat-item/chat-item.vue";
import userSettingModel from "@/components/user-model/user-setting-model.vue";
export default {
  name: "AiChat",
  components: {
    chatInputBar,
    chatItem,
    userSettingModel,
  },
  data() {
    return {
      chatIntegral: 0,
      talkList: [],
      content: "",
      show: false,
      sendState: false,
      isTyping: false,
      currentMassage: {},
      currentIndex: 0,
      currentContent: "",
      typingInterval: 50,
      userInfo: null,
      imitateMsgList: [
        // {is_end:false,result:'你好，这是一条模拟消息回复。'},
        // {is_end:false,result:'请问有什么问题我可以为您解答吗？'},
        // {is_end:false,result:'我可以协助您完成范围广泛的任务并提供有关各种主题的信息，比如回答问题，提供定义和解释及建议，如果您有任何具体需要帮助，可以随时问我，'},
        // {is_end:true,result:'我很乐意为您提供帮助。'},
      ],
      imitateIndex: 0,
      useSSE: true,
      useContinueChat: true,
      modelTypeValue: MODEL_TYPE[0].value, // 默认模型
      abortController: null, // 用于SSE请求中断
      typingTimer: null, // 新增定时器引用
    };
  },
  onLoad(options) {
    // 组件创建时读取设置
    this.userInfo = this.getLoginUserInfo();
    // 获取用户的配置
    const savedSettings = localStorage.getItem("userSettings");
    if (savedSettings) {
      try {
        const { sse, continuous, modelType } = JSON.parse(savedSettings);
        this.useSSE = !!sse;
        this.useContinueChat = !!continuous;
        this.modelTypeValue =
          MODEL_TYPE.find((item) => item.label === modelType)?.value ||
          MODEL_TYPE[0].value;
      } catch (e) {
        console.error("初始化设置失败", e);
      }
    }
  },
  watch: {
    // 新增监听器
    talkList: {
      handler(newVal) {
        uni.setStorageSync("chatHistory", newVal);
      },
      deep: true,
    },
  },
  methods: {
    updateUserInfo() {
      this.userInfo = this.getLoginUserInfo();
    },
    // 获取历史消息
    getHistoryMsg() {
      let get = async () => {
        const data = uni.getStorageSync("chatHistory") || [
          {
            content:
              globalData.appName +
              "为您服务：<br/> 1.知乎百度答题、做作业题目<br/>2.写代码、写文案、写论文，写小说<br/>3.文案润色、翻译、写诗作词<br/>4.扮演面试官、扮演书籍电影角色<br/>例1：写一篇工作日报我是行政<br/>例2：帮我写作业，题目是xxx<br/>例3：把下文翻译成英文：xxx<br/>例4：写一出能活的短视频剧本<br/>例5：英文写物理相关的论文<br/>或者可以问我其他问题<br/>越完整的描述，我越精确", // 消息内容
            type: 0, // 此为消息类别，设 1 为发出去的消息，0 为收到对方的消息,
            state: 0,
            icon: "/static/logo.png",
            end: true,
          },
        ];
        this.$refs.paging.complete(data);
      };
      get();
    },
    // 监听键盘高度改变，请不要直接通过uni.onKeyboardHeightChange监听，否则可能导致z-paging内置的键盘高度改变监听失效（如果不需要切换表情面板则不用写）
    keyboardHeightChange(res) {
      this.$refs.inputBar.updateKeyboardHeightChange(res);
    },
    // 用户尝试隐藏键盘，此时如果表情面板在展示中，应当通知chatInputBar隐藏表情面板（如果不需要切换表情面板则不用写）
    hidedKeyboard() {
      this.$refs.inputBar.hidedKeyboard();
    },
    startTyping() {
      if (this.isTyping) return;
      var that = this;
      this.isTyping = true;
      this.typingTimer = setTimeout(() => {
        if (this.currentIndex <= this.currentContent.length) {
          that.talkList[0].state = 1;
          that.talkList[0].content = this.currentContent.substring(
            0,
            this.currentIndex++
          );
          // 设置当前滚动的位置
          //that.setPageScrollTo();
          this.isTyping = false;
          this.startTyping();
        } else {
          if (this.currentMassage.is_end) {
            that.talkList[0].end = true;
            that.$data.currentIndex = 0;
            that.$data.currentContent = "";
            that.$data.sendState = false;
          }
          this.isTyping = false;
        }
      }, this.typingInterval);
    },
    handleopen() {
      this.$refs.settingPopup.openSettings();
    },
    updateUserSetting() {
      const savedSettings = localStorage.getItem("userSettings");
      if (savedSettings) {
        try {
          const sse = JSON.parse(savedSettings).sse;
          const continuous = JSON.parse(savedSettings).continuous;
          const modelType = JSON.parse(savedSettings).modelType;
          this.useSSE = !!sse;
          this.useContinueChat = !!continuous;
          this.modelTypeValue =
            MODEL_TYPE.find((item) => item.label === modelType)?.value ||
            MODEL_TYPE[0].value;
        } catch (e) {
          console.error("设置读取失败", e);
        }
      }
    },
    resetList() {
      this.getHistoryMsg();
    },
    send(msg) {
      var that = this;
      that.content = msg;
      if (!that.content) {
        that.$refs.uTips.show({
          title: "请输入有效的内容",
          type: "error",
          duration: "2300",
        });
        return false;
      }
      // 添加锁，避免重复发送
      if (this.$data.sendState) {
        return false;
      }
      that.$data.sendState = true;
      // 清空输入框内容
      that.$refs.inputBar.setMsg("");
      // 向聊天面板添加一条我发送的消息
      that.talkList = [
        // 模拟一条当先需要回复消息，当消息内容为空时，显示加载中图标
        {
          content: "", // 消息内容
          type: 0, // 此为消息类别，设 1 为发出去的消息，0 为收到对方的消息,
          end: false, // 是否完毕，当消息为对方发送的消息时，如果未完毕则显示对方流式相应光标
          icon: "/static/logo.png",
        },
        {
          content: that.content, // 消息内容
          type: 1, // 此为消息类别，设 1 为发出去的消息，0 为收到对方的消息,
          end: true, // 是否完毕
          icon:
            this.userInfo && this.userInfo.icon
              ? this.userInfo.icon
              : "/static/avatar.png",
        },
        ...that.talkList,
      ];

      // 回复消息归0，从第一条开始，现实流式响应也是一段一段的收到消息并且进行响应
      this.imitateIndex = 0;
      this.toSend();
    },
    // 模拟信息的回复
    async toSend() {
      const that = this;
      const messages = JSON.parse(JSON.stringify(that.talkList))
        .reverse()
        .map((item) => ({
          role: item.type === 1 ? "user" : "assistant",
          content: item.content,
        }));
      // 删除第一条提示内容和最后一条空白内容
      messages.shift();
      messages.pop();
      const api = MODEL_TYPE.find(
        (item) => item.value === that.modelTypeValue
      ).api;
      if (that.useSSE) {
        try {
          that.abortController = new AbortController(); // 创建中断控制器
          const response = await fetch(api, {
            method: "POST",
            headers: {
              "Content-Type": "application/json",
              Authorization: "Bearer MoMbElcjFzfiJJqegafi:gVyTMPfepZiLGQSFuDoC",
            },
            body: JSON.stringify({
              model: that.modelTypeValue,
              messages: that.useContinueChat
                ? messages
                : [
                    {
                      role: "user",
                      content: that.content, // 根据当前内容回答
                    },
                  ],
              stream: true,
            }),
            signal: that.abortController.signal, // 添加中断信号
          });
          if (!response.body) {
            throw new Error("服务器未返回流数据");
          }
          const reader = response.body.getReader();
          const decoder = new TextDecoder("utf-8");
          let buffer = ""; // 用于保存未处理完的分块数据

          while (true) {
            const { done, value } = await reader.read();
            if (done) break; // 读取结束

            const chunk = decoder.decode(value, { stream: true });
            buffer += chunk; // 将新数据拼接到缓冲区

            // 按换行符分割数据块
            const lines = buffer.split("\n");

            // 最后一行可能是不完整数据块，留到下一次处理
            buffer = lines.pop();
            for (const line of lines) {
              if (line.startsWith("data: ")) {
                const jsonStr = line.slice(6).trim(); // 去掉 "data: " 前缀
                if (jsonStr !== "[DONE]") {
                  try {
                    const jsonData = JSON.parse(jsonStr);
                    // 存在推理内容，优先展示推理把内容，最后展示真实总结内容
                    const content =
                      jsonData.choices[0]?.delta?.reasoning_content ||
                      jsonData.choices[0]?.delta?.content;
                    if (content) {
                      // 实时触发回调  这个回调是为了能在页面上实时输出
                      that.imitateMsgList.push({
                        is_end: false,
                        result: content,
                      });
                      that.currentMassage =
                        that.imitateMsgList[that.imitateIndex];
                      that.currentContent += content;
                      that.startTyping();
                      that.imitateIndex++;
                    }
                  } catch (error) {
                    console.error("解析 JSON 数据失败:", error, line);
                  }
                } else {
                  that.currentMassage = {
                    is_end: true,
                    result: "",
                  };
                }
              }
            }
          }
        } catch (error) {
          if (error.name === "AbortError") {
            console.log("请求已被主动取消");
          } else {
            console.error("流式数据请求失败:", error);
          }
        }
      } else {
        uni.request({
          url: api,
          method: "POST",
          data: {
            model: that.modelTypeValue,
            messages: that.useContinueChat
              ? messages
              : [
                  {
                    role: "user",
                    content: that.content, // 根据当前内容回答
                  },
                ],
            stream: false,
          },
          header: {
            "Content-Type": "application/json",
            Authorization: "Bearer MoMbElcjFzfiJJqegafi:gVyTMPfepZiLGQSFuDoC",
          },
          success: (res) => {
            console.log(res.data.choices[0].message.content);
            // 下面模拟请求
            that.imitateMsgList = [
              {
                is_end: true,
                result: res.data.choices[0].message.content,
              },
            ];
            that.currentMassage = that.imitateMsgList[that.imitateIndex];
            that.currentContent += that.currentMassage.result;
            that.startTyping();
            if (that.imitateIndex >= that.imitateMsgList.length - 1) {
              // 回复完毕
              that.imitateIndex = 0;
            } else {
              // 下一条，直到回复完毕
              that.imitateIndex++;
              that.toSend();
            }
          },
        });
      }
    },
    // 停止会话
    stopChat() {
      // 清除所有等待中的定时器
      clearTimeout(this.typingTimer);

      // 中断SSE请求
      if (this.abortController) {
        this.abortController.abort();
        this.abortController = null;
      }

      // 重置状态
      this.currentIndex = 0;
      this.isTyping = false;
      this.sendState = false;

      // 如果存在未完成的消息，标记为已完成
      if (this.talkList[0] && !this.talkList[0].end) {
        this.$set(this.talkList[0], "end", true);
        this.$set(this.talkList[0], "content", this.currentContent);
      }
      console.log("会话已停止");
    },
  },
};
</script>

<style lang="scss">
page {
  background-color: #f3f3f3;
  font-size: 28rpx;
  box-sizing: border-box;
  color: #333;
  letter-spacing: 0;
  word-wrap: break-word;
}
</style>
