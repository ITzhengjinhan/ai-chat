<template>
  <u-popup
    ref="settingPopup"
    :show="settingShow"
    :round="10"
    mode="bottom"
    @close="closeSetting"
    closeable
  >
    <view class="setting-popup">
      <view class="title">对话设置</view>

      <!-- SSE开关 -->
      <view class="setting-item">
        <text>启用SSE流式接口</text>
        <u-switch
          v-model="sseEnabled"
          active-color="#007aff"
          size="28"
        ></u-switch>
      </view>

      <!-- 连续对话开关 -->
      <view class="setting-item">
        <text>启用连续对话模式</text>
        <u-switch
          v-model="continuousDialogEnabled"
          active-color="#007aff"
          size="28"
        ></u-switch>
      </view>

      <!-- 模型切换 -->
      <view class="setting-item">
        <text>模型切换</text>
        <u-picker
          mode="selector"
          v-model="showSelector"
          :default-selector="defaultSelectorIndex"
          range-key="label"
          :range="selector"
          confirm-color="rgb(0, 122, 255)"
          @confirm="confirmSelector"
        ></u-picker>
        <view @click="showSelector = true"
          ><text class="selector-txt">{{
            selectorValue || "请选择模型"
          }}</text></view
        >
      </view>

      <view class="btn-box">
        <u-button
          @click="clearLocalstorage"
          color="#007aff"
          text="开启新会话"
          class="btn"
          >开启新会话</u-button
        >
        <u-button
          @click="saveSettings"
          color="#007aff"
          text="保存设置"
          class="btn"
          type="primary"
          >保存设置</u-button
        >
      </view>
    </view>
  </u-popup>
</template>

<script>
import { MODEL_TYPE } from "../../constant/model.js";
export default {
  name: "user-setting-model",
  props: {},
  created() {
    // 组件创建时读取设置
    this.init();
  },
  data() {
    return {
      // 弹窗显示状态
      settingShow: false,
      // switch开关参数
      sseEnabled: true,
      continuousDialogEnabled: true,
      // picker参数
      showSelector: false,
      selector: MODEL_TYPE,
      selectorValue: MODEL_TYPE[0].label,
      defaultSelectorIndex: [0],
    };
  },
  methods: {
    init() {
      const savedSettings = localStorage.getItem("userSettings");
      if (savedSettings) {
        try {
          const { sse, continuous, modelType } = JSON.parse(savedSettings);
          this.sseEnabled = !!sse;
          this.continuousDialogEnabled = !!continuous;
          this.selectorValue = modelType;
          this.defaultSelectorIndex = [
            MODEL_TYPE.findIndex((item) => item.label === modelType),
          ];
        } catch (e) {
          console.error("初始化设置失败", e);
        }
      }
    },
    // 打开设置弹窗
    openSettings() {
      this.settingShow = true;
      this.$refs.settingPopup.open();
    },

    // 关闭弹窗
    closeSetting() {
      this.settingShow = false;
      // 重置为初始化状态
      this.init();
    },

    // 保存设置
    saveSettings() {
      // 新增存储代码
      localStorage.setItem(
        "userSettings",
        JSON.stringify({
          sse: this.sseEnabled,
          continuous: this.continuousDialogEnabled,
          modelType: this.selectorValue,
        })
      );
      this.$emit("settings-change", {
        sse: this.sseEnabled,
        continuous: this.continuousDialogEnabled,
      });
      this.$refs.settingPopup.close();
    },

    // 开启新会话
    clearLocalstorage() {
      localStorage.removeItem("chatHistory");
      this.$refs.settingPopup.close();
      this.$emit("resetList");
    },
    // 选择模型回调
    confirmSelector(selectedValues) {
      this.selectorValue = MODEL_TYPE[selectedValues[0]].label;
      this.defaultSelectorIndex = [selectedValues[0]];
    },
  },
};
</script>

<style lang="scss">
.setting-popup {
  padding: 40rpx;
  background: #fff;
  border-radius: 20rpx;

  .title {
    font-size: 34rpx;
    font-weight: bold;
    text-align: center;
    margin-bottom: 40rpx;
    color: #333;
  }

  .setting-item {
    display: flex;
    justify-content: space-between;
    align-items: center;
    padding: 30rpx 0;
    border-bottom: 1rpx solid #eee;

    text {
      font-size: 30rpx;
      color: #333;
    }

    &:last-child {
      border-bottom: none;
    }
    .selector-txt {
      font-size: 28rpx;
      color: #999;
      vertical-align: middle;
      &::after {
        display: inline-block;
        content: ">";
        margin-left: 8rpx;
      }
    }
  }
  .btn-box {
    display: flex;
    margin-top: 24rpx;
    gap: 72rpx;
    .btn {
      width: 50%;
    }
  }
}
</style>
