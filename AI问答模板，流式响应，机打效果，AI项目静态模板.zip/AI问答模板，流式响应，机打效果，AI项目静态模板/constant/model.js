export const MODEL_TYPE = [
  {
    value: "4.0Ultra",
    label: "spark4.0 Ultra",
    api: "/api/v1/chat/completions",
  },
  {
    value: "x1",
    label: "spark X1深度推理",
    api: "/api/v2/chat/completions",
  },
];
