exports.install = function (Vue, options) {
	//获得玩家登录信息
	Vue.prototype.getLoginUserInfo = function (){
		var ret = null;
		try{
			var result = uni.getStorageSync('USERINFO');
			if(result!="undefined"){
				var userInfo = JSON.parse(result);
				ret = userInfo
			}
		}catch(e){
			//TODO handle the exception
		}
		return ret;
	};
	// 生成唯一id存在用户设备中，用来做统计使用
	Vue.prototype.getUuid = function(){
		var Uuid = uni.getStorageSync('USERUNIID');
		if(!Uuid){
			Uuid = Number(Math.random().toString().substr(3,20) + Date.now()).toString(36);
			uni.setStorage({
				key: 'USERUNIID',
				data: Uuid,//0游客 1用户
				success: function () {
				},
				fail:function(){
				}
			});
		}
		return Uuid;
	};
	/**
	 * 操作失败
	 * **/
	Vue.prototype.operError = function (){
		uni.showToast({
			title: '操作错误',
			icon:'none',
			duration:1500
		});
		setTimeout(function(){
			uni.switchTab({
				url: '/pages/index/index'
			});
		},1500);
	};
};