<script>
export default {
  globalData: {
    language: "zh_cn",
    appToken: "",
    app_sign_key: "@#1234A98413G=--..234",
    windowWidth: "",
    windowHeight: "",
    appName: "默小涵",
    // nav 背景颜色和字体颜色,可用于制定用户自定义风格
    navBackgroundColor: "#ffffff",
    navFontColor: "#041415",
  },
  onLaunch: function (options) {},
  onShow: function () {
    console.log("App Show");
  },
  onHide: function () {
    console.log("App Hide");
  },
};
</script>

<style lang="scss">
@import "uview-ui/index.scss";
</style>
